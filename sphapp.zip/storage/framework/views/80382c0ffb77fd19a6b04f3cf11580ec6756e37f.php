<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
    <h1>Edit the selected computer.</h1>
    <?php echo Form::open(['action' => ['ComputersController@update', $computer->id], 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('serialnumber', 'Serial Number')); ?>

            <?php echo e(Form::text('serialnumber', $computer->serialnumber , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('username', 'User Name')); ?>

            <?php echo e(Form::text('username', $computer->username , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('hostname', 'Host Name')); ?>

            <?php echo e(Form::text('hostname', $computer->hostname , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('manufacturer', 'Manufacturer')); ?>

            <?php echo e(Form::text('manufacturer', $computer->manufacturer , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('model', 'Model')); ?>

            <?php echo e(Form::text('model', $computer->model , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cpumodel', 'CPU Model')); ?>

            <?php echo e(Form::text('cpumodel', $computer->cpumodel , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('memory', 'Memory')); ?>

            <?php echo e(Form::text('memory', $computer->memory , ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <?php echo e(Form::hidden('_method', 'PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary', 'id' => 'addPcSubmit'])); ?>

    <?php echo Form::close(); ?>


    <?php echo Form::open(['action' => ['ComputersController@destroy', $computer->id], 'method' => 'POST']); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

    <?php echo Form::close(); ?>



</div>