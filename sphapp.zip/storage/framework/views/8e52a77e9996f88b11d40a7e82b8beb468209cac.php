<?php $__env->startSection('content'); ?>
  <div class="form-inline">
    <h1 class="mr-auto">SPH Computers</h1>
    <a class="btn btn-dark mb-2" href="/computers/create">Add Computer</a>
</div>
<div class="well">
  <table id="computers-datatable" class="table table-striped">
      <thead>
        <tr>
          <th scope="col">Serial Number</th>
          <th scope="col">User Name</th>
          <th scope="col">Computer Name</th>
          <th scope="col">Manufacturer</th>
          <th scope="col">Model</th>
          <th scope="col">CPU Model</th>
          <th scope="col">Memory</th>
          <th scope="col">Actions</th>

        </tr>
      </thead>
      <tbody>
        <?php if(count($computers) > 1): ?>
          <?php $__currentLoopData = $computers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $computer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($computer->serialnumber); ?></td>
              <td><?php echo e($computer->username); ?></td>
              <td><?php echo e($computer->hostname); ?></td>
              <td><?php echo e($computer->manufacturer); ?></td>
              <td><?php echo e($computer->model); ?></td>
              <td><?php echo e($computer->cpumodel); ?></td>
              <td><?php echo e($computer->memory); ?></td>
              <td>
                <a class="btn btn-sm btn-success" href="/computers/<?php echo e($computer->id); ?>/edit">Edit</a>
                <a class="btn btn-sm btn-danger" href="/computers/<?php echo e($computer->id); ?>/delete">Delete</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <p>No computers found to display</p>
        <?php endif; ?>
      </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>