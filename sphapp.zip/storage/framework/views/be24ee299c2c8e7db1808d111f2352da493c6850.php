<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
    <h1>Add a computer to the list.</h1>
    <?php echo Form::open(['action' => 'ComputersController@store', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('serialnumber', 'Serial Number')); ?>

            <?php echo e(Form::text('serialnumber', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('username', 'User Name')); ?>

            <?php echo e(Form::text('username', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('hostname', 'Host Name')); ?>

            <?php echo e(Form::text('hostname', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('manufacturer', 'Manufacturer')); ?>

            <?php echo e(Form::text('manufacturer', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('model', 'Model')); ?>

            <?php echo e(Form::text('model', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cpumodel', 'CPU Model')); ?>

            <?php echo e(Form::text('cpumodel', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('memory', 'Memory')); ?>

            <?php echo e(Form::text('memory', '', ['class' => 'form-control', 'placeholder' => 'Enter here...'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary', 'id' => 'addPcSubmit'])); ?>

    <?php echo Form::close(); ?>

</div>