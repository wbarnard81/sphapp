<?php
/**
 * Created by PhpStorm.
 * User: Werner
 * Date: 06-Aug-18
 * Time: 10:16 AM
 */

$jokeContent = file_get_contents('http://api.icndb.com/jokes/random');
$jokesArray = json_decode($jokeContent, true);
$joke = $jokesArray['value']['joke'];
echo $joke;
